
function setup() {
  createCanvas(700, 700);
}

function draw() {
  background(240);

  // Desenhando o quadrado rosa
  fill(255, 105, 180);  // Cor rosa
  rect(200, 200, 400, 400);  // Posição x, Posição y, Largura, Altura

  // Desenhando o círculo azul
  fill(0, 0, 255);  // Cor azul
  ellipse(400, 400, 200, 200);  // Posição x, Posição y, Largura, Altura
}